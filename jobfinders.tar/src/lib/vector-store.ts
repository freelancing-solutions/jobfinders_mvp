import { Pinecone } from '@pinecone-database/pinecone'

// Only create Pinecone instance if environment variables are available
let pinecone: Pinecone | null = null;

if (process.env.PINECONE_API_KEY) {
  pinecone = new Pinecone({
    apiKey: process.env.PINECONE_API_KEY,
  });
}

export function createVectorStore() {
  return {
    upsert: async (vectors: any[]) => {
      if (!pinecone) {
        console.log('Vector store not configured - skipping upsert');
        return;
      }
      // Placeholder implementation
      console.log('Vector store upsert:', vectors);
    },
    query: async (vector: number[], topK: number = 5) => {
      if (!pinecone) {
        console.log('Vector store not configured - returning empty results');
        return [];
      }
      // Placeholder implementation
      console.log('Vector store query:', vector, topK);
      return [];
    }
  };
}

export default pinecone