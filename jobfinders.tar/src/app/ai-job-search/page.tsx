import { AIJobSearch } from '@/components/jobs/ai-job-search';

export default function AIJobSearchPage() {
  return <AIJobSearch />;
}