import { aiService, AIResponse } from './ai-service';

export interface ResumeSection {
  title: string;
  content: string;
  suggestions?: string[];
}

export interface ResumeAnalysis {
  overallScore: number;
  sections: {
    summary: ResumeSection;
    experience: ResumeSection;
    education: ResumeSection;
    skills: ResumeSection;
  };
  atsOptimization: {
    score: number;
    suggestions: string[];
    missingKeywords: string[];
  };
  improvements: {
    content: string[];
    formatting: string[];
    keywords: string[];
  };
}

export interface ResumeTemplate {
  id: string;
  name: string;
  description: string;
  industry: string;
  sections: string[];
}

export class ResumeBuilderService {
  private readonly systemPrompt = `You are an expert resume writer and career coach with deep knowledge of ATS (Applicant Tracking Systems) and modern hiring practices. Your goal is to help job seekers create professional, effective resumes that get past ATS systems and impress hiring managers.`;

  async analyzeResume(resumeText: string, jobDescription?: string): Promise<ResumeAnalysis | null> {
    const prompt = `Analyze the following resume${jobDescription ? ' for this job description' : ''} and provide a comprehensive analysis:

${jobDescription ? `Job Description:\n${jobDescription}\n\n` : ''}
Resume Text:\n${resumeText}

Please provide a detailed analysis in JSON format with the following structure:
{
  "overallScore": number (0-100),
  "sections": {
    "summary": {
      "title": "Professional Summary",
      "content": "analysis of summary section",
      "suggestions": ["improvement suggestions"]
    },
    "experience": {
      "title": "Work Experience",
      "content": "analysis of experience section",
      "suggestions": ["improvement suggestions"]
    },
    "education": {
      "title": "Education",
      "content": "analysis of education section",
      "suggestions": ["improvement suggestions"]
    },
    "skills": {
      "title": "Skills",
      "content": "analysis of skills section",
      "suggestions": ["improvement suggestions"]
    }
  },
  "atsOptimization": {
    "score": number (0-100),
    "suggestions": ["ATS optimization suggestions"],
    "missingKeywords": ["important keywords missing from resume"]
  },
  "improvements": {
    "content": ["content improvement suggestions"],
    "formatting": ["formatting improvement suggestions"],
    "keywords": ["keyword optimization suggestions"]
  }
}`;

    return await aiService.generateJSON<ResumeAnalysis>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.3,
    });
  }

  async generateSummary(
    experience: string,
    skills: string[],
    targetRole?: string
  ): Promise<string | null> {
    const prompt = `Generate a compelling professional summary based on the following information:

Experience: ${experience}
Skills: ${skills.join(', ')}
${targetRole ? `Target Role: ${targetRole}` : ''}

Create a concise, impactful professional summary (3-4 sentences) that:
- Highlights key achievements and skills
- Aligns with ${targetRole || 'the target role'}
- Uses strong action verbs
- Includes relevant keywords for ATS optimization
- Shows career progression and value proposition`;

    const response = await aiService.generateText(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.7,
    });

    return response.error ? null : response.content;
  }

  async optimizeExperience(
    originalDescription: string,
    targetRole?: string
  ): Promise<string | null> {
    const prompt = `Optimize the following work experience description for maximum impact and ATS compatibility:

Original Description: ${originalDescription}
${targetRole ? `Target Role: ${targetRole}` : ''}

Please rewrite this experience description to:
- Use strong action verbs and quantifiable achievements
- Include relevant keywords for ${targetRole || 'the target industry'}
- Highlight impact and results (use numbers, percentages, metrics)
- Be concise but comprehensive
- Optimize for ATS systems
- Follow the STAR method (Situation, Task, Action, Result) where applicable

Provide the optimized description only.`;

    const response = await aiService.generateText(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.6,
    });

    return response.error ? null : response.content;
  }

  async extractSkills(text: string): Promise<{ technical: string[]; soft: string[] }> {
    const prompt = `Extract and categorize all skills from the following text. Separate them into technical skills and soft skills.

Text: ${text}

Please respond with a JSON object in this format:
{
  "technical": ["skill1", "skill2", ...],
  "soft": ["skill1", "skill2", ...]
}`;

    return await aiService.generateJSON<{ technical: string[]; soft: string[] }>(prompt, {
      systemPrompt: 'You are an expert at identifying and categorizing skills from professional text.',
      temperature: 0.2,
    });
  }

  async generateCoverLetter(
    resumeText: string,
    jobDescription: string,
    companyName: string
  ): Promise<string | null> {
    const prompt = `Generate a personalized cover letter based on the resume and job description:

Resume: ${resumeText}
Job Description: ${jobDescription}
Company: ${companyName}

Create a compelling cover letter that:
- Addresses the hiring manager personally
- Shows understanding of the company and role
- Highlights relevant experience and skills from the resume
- Explains why the candidate is a good fit
- Includes specific examples and achievements
- Has a professional tone and structure
- Is concise (3-4 paragraphs)`;

    const response = await aiService.generateText(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.7,
    });

    return response.error ? null : response.content;
  }

  async getResumeTemplates(): Promise<ResumeTemplate[]> {
    // Return predefined templates - in a real app, this could come from a database
    return [
      {
        id: 'modern',
        name: 'Modern Professional',
        description: 'Clean, contemporary design perfect for tech and creative roles',
        industry: 'Technology',
        sections: ['summary', 'experience', 'skills', 'education'],
      },
      {
        id: 'executive',
        name: 'Executive',
        description: 'Traditional format suitable for senior management and executive roles',
        industry: 'Business',
        sections: ['summary', 'experience', 'education', 'skills', 'certifications'],
      },
      {
        id: 'creative',
        name: 'Creative',
        description: 'Visually appealing design for creative industries',
        industry: 'Design',
        sections: ['summary', 'experience', 'portfolio', 'skills', 'education'],
      },
      {
        id: 'academic',
        name: 'Academic',
        description: 'Format optimized for academic and research positions',
        industry: 'Education',
        sections: ['summary', 'education', 'research', 'publications', 'skills'],
      },
    ];
  }
}

export const resumeBuilderService = new ResumeBuilderService();