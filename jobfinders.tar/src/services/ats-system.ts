import { aiService } from './ai-service';
import { redis } from '@/lib/redis';

export interface ATSAnalysisResult {
  score: number;
  breakdown: {
    keywords: {
      score: number;
      matched: string[];
      missing: string[];
      partial: string[];
    };
    experience: {
      score: number;
      yearsMatch: boolean;
      levelMatch: boolean;
    };
    skills: {
      score: number;
      matched: string[];
      missing: string[];
      proficiency: { [key: string]: string };
    };
    education: {
      score: number;
      degreeMatch: boolean;
      fieldMatch: boolean;
    };
    format: {
      score: number;
      issues: string[];
      suggestions: string[];
    };
  };
  suggestions: string[];
  ranking: 'excellent' | 'good' | 'fair' | 'poor';
  confidence: number;
}

export interface JobRequirements {
  title: string;
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experience: {
    minYears: number;
    level: 'entry' | 'mid' | 'senior' | 'executive';
  };
  education: {
    degree: string;
    field?: string;
  };
  keywords: string[];
}

export class ATSSystem {
  private readonly systemPrompt = `You are an expert ATS (Applicant Tracking System) analyzer with deep knowledge of how companies screen resumes. Your analysis helps job seekers understand how their resumes will be scored by automated systems.`;

  async analyzeResumeMatch(
    resumeText: string,
    jobDescription: string,
    requirements?: JobRequirements
  ): Promise<ATSAnalysisResult | null> {
    // Try to get from cache first
    const cacheKey = `ats:${Buffer.from(resumeText + jobDescription).toString('base64').slice(0, 50)}`;
    
    if (redis) {
      try {
        const cached = await redis.get(cacheKey);
        if (cached) {
          return JSON.parse(cached);
        }
      } catch (error) {
        console.log('Cache miss, proceeding with analysis');
      }
    }

    // If no requirements provided, extract them from job description
    const extractedRequirements = requirements || await this.extractJobRequirements(jobDescription);
    
    const prompt = `Analyze the following resume against the job description and provide a detailed ATS analysis:

Job Description:
${jobDescription}

Resume Text:
${resumeText}

Job Requirements:
${JSON.stringify(extractedRequirements, null, 2)}

Please provide a comprehensive ATS analysis in JSON format with the following structure:
{
  "score": number (0-100),
  "breakdown": {
    "keywords": {
      "score": number (0-100),
      "matched": ["matched keywords"],
      "missing": ["missing keywords"],
      "partial": ["partially matched keywords"]
    },
    "experience": {
      "score": number (0-100),
      "yearsMatch": boolean,
      "levelMatch": boolean
    },
    "skills": {
      "score": number (0-100),
      "matched": ["matched skills"],
      "missing": ["missing skills"],
      "proficiency": {"skill": "proficiency level"}
    },
    "education": {
      "score": number (0-100),
      "degreeMatch": boolean,
      "fieldMatch": boolean
    },
    "format": {
      "score": number (0-100),
      "issues": ["format issues"],
      "suggestions": ["format suggestions"]
    }
  },
  "suggestions": ["improvement suggestions"],
  "ranking": "excellent" | "good" | "fair" | "poor",
  "confidence": number (0-1)
}`;

    const result = await aiService.generateJSON<ATSAnalysisResult>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.2,
    });

    // Cache the result
    if (result && redis) {
      try {
        await redis.setex(cacheKey, 3600, JSON.stringify(result)); // Cache for 1 hour
      } catch (error) {
        console.error('Failed to cache ATS result:', error);
      }
    }

    return result;
  }

  async extractJobRequirements(jobDescription: string): Promise<JobRequirements> {
    const prompt = `Extract structured job requirements from the following job description:

Job Description:
${jobDescription}

Please extract and return a JSON object with the following structure:
{
  "title": "job title",
  "description": "brief description",
  "requiredSkills": ["skill1", "skill2"],
  "preferredSkills": ["skill1", "skill2"],
  "experience": {
    "minYears": number,
    "level": "entry" | "mid" | "senior" | "executive"
  },
  "education": {
    "degree": "degree type",
    "field": "field of study (optional)"
  },
  "keywords": ["keyword1", "keyword2"]
}`;

    return await aiService.generateJSON<JobRequirements>(prompt, {
      systemPrompt: 'You are an expert at parsing job descriptions and extracting structured requirements.',
      temperature: 0.1,
    }) || {
      title: '',
      description: '',
      requiredSkills: [],
      preferredSkills: [],
      experience: { minYears: 0, level: 'entry' },
      education: { degree: '' },
      keywords: [],
    };
  }

  async optimizeResumeForATS(
    resumeText: string,
    jobDescription: string,
    targetKeywords: string[]
  ): Promise<string | null> {
    const prompt = `Optimize the following resume for better ATS performance based on the job description and target keywords:

Resume Text:
${resumeText}

Job Description:
${jobDescription}

Target Keywords:
${targetKeywords.join(', ')}

Please rewrite the resume to:
1. Naturally incorporate the target keywords
2. Maintain readability and professional tone
3. Highlight relevant experience and skills
4. Use standard resume formatting that ATS systems can parse
5. Include industry-specific terminology
6. Quantify achievements where possible
7. Ensure all sections are clearly labeled

Provide the optimized resume text only.`;

    const response = await aiService.generateText(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.4,
    });

    return response.error ? null : response.content;
  }

  async generateKeywordSuggestions(
    jobDescription: string,
    industry: string
  ): Promise<string[]> {
    const prompt = `Generate relevant keywords for a resume targeting this job description in the ${industry} industry:

Job Description:
${jobDescription}

Please provide a comprehensive list of keywords that:
1. Are commonly used in ${industry} job descriptions
2. Are important for ATS systems
3. Include technical skills, soft skills, and industry terms
4. Cover tools, technologies, and methodologies
5. Include action verbs and achievement metrics

Return as a JSON array of strings.`;

    const result = await aiService.generateJSON<string[]>(prompt, {
      systemPrompt: 'You are an expert in industry-specific keywords and ATS optimization.',
      temperature: 0.3,
    });

    return result || [];
  }

  async calculateMatchScore(
    resumeText: string,
    jobDescription: string
  ): Promise<{ score: number; factors: { [key: string]: number } }> {
    const prompt = `Calculate a detailed match score between the following resume and job description:

Resume:
${resumeText}

Job Description:
${jobDescription}

Please provide a JSON object with:
{
  "score": number (0-100),
  "factors": {
    "skillsMatch": number (0-100),
    "experienceMatch": number (0-100),
    "educationMatch": number (0-100),
    "keywordDensity": number (0-100),
    "formatScore": number (0-100)
  }
}`;

    return await aiService.generateJSON<{ score: number; factors: { [key: string]: number } }>(prompt, {
      systemPrompt: 'You are an expert at calculating resume-job match scores.',
      temperature: 0.1,
    }) || { score: 0, factors: {} };
  }
}

export const atsSystem = new ATSSystem();