'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, 
  Wand2, 
  Target, 
  Brain, 
  Download, 
  Save,
  Eye,
  Sparkles,
  TrendingUp,
  CheckCircle,
  Edit as EditIcon,
  Briefcase
} from 'lucide-react';

interface ResumeData {
  personalInfo: {
    name: string;
    email: string;
    phone: string;
    location: string;
    linkedin: string;
    website: string;
  };
  summary: string;
  experience: Array<{
    id: string;
    company: string;
    position: string;
    startDate: string;
    endDate: string;
    isCurrent: boolean;
    description: string;
  }>;
  education: Array<{
    id: string;
    institution: string;
    degree: string;
    field: string;
    startDate: string;
    endDate: string;
    isCurrent: boolean;
    gpa?: string;
  }>;
  skills: {
    technical: string[];
    soft: string[];
  };
  projects: Array<{
    id: string;
    title: string;
    description: string;
    technologies: string[];
    url?: string;
    startDate: string;
    endDate: string;
  }>;
}

interface ResumeAnalysis {
  overallScore: number;
  sections: {
    summary: { content: string; suggestions: string[] };
    experience: { content: string; suggestions: string[] };
    education: { content: string; suggestions: string[] };
    skills: { content: string; suggestions: string[] };
  };
  atsOptimization: {
    score: number;
    suggestions: string[];
    missingKeywords: string[];
  };
  improvements: {
    content: string[];
    formatting: string[];
    keywords: string[];
  };
}

export function ResumeBuilder() {
  const [resumeData, setResumeData] = useState<ResumeData>({
    personalInfo: {
      name: '',
      email: '',
      phone: '',
      location: '',
      linkedin: '',
      website: '',
    },
    summary: '',
    experience: [],
    education: [],
    skills: { technical: [], soft: [] },
    projects: [],
  });

  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [jobDescription, setJobDescription] = useState('');
  const [activeTab, setActiveTab] = useState('edit');
  const [aiSuggestions, setAiSuggestions] = useState<{ [key: string]: string }>({});

  const handleAnalyzeResume = async () => {
    setIsAnalyzing(true);
    try {
      const resumeText = generateResumeText(resumeData);
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'analyze-resume',
          params: {
            resumeText,
            jobDescription: jobDescription || undefined,
          },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setAnalysis(result);
      }
    } catch (error) {
      console.error('Failed to analyze resume:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGenerateSummary = async () => {
    try {
      const experience = resumeData.experience
        .map(exp => `${exp.position} at ${exp.company}`)
        .join(', ');
      
      const allSkills = [...resumeData.skills.technical, ...resumeData.skills.soft];

      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'generate-summary',
          params: {
            experience,
            skills: allSkills,
            targetRole: jobDescription ? extractJobTitle(jobDescription) : undefined,
          },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setAiSuggestions(prev => ({
          ...prev,
          summary: result.summary,
        }));
      }
    } catch (error) {
      console.error('Failed to generate summary:', error);
    }
  };

  const handleOptimizeExperience = async (experienceId: string, description: string) => {
    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'optimize-experience',
          params: {
            originalDescription: description,
            targetRole: jobDescription ? extractJobTitle(jobDescription) : undefined,
          },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setAiSuggestions(prev => ({
          ...prev,
          [`experience-${experienceId}`]: result.optimized,
        }));
      }
    } catch (error) {
      console.error('Failed to optimize experience:', error);
    }
  };

  const handleExtractSkills = async (text: string) => {
    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'extract-skills',
          params: { text },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setResumeData(prev => ({
          ...prev,
          skills: {
            technical: [...prev.skills.technical, ...result.technical],
            soft: [...prev.skills.soft, ...result.soft],
          },
        }));
      }
    } catch (error) {
      console.error('Failed to extract skills:', error);
    }
  };

  const generateResumeText = (data: ResumeData): string => {
    return `
Name: ${data.personalInfo.name}
Email: ${data.personalInfo.email}
Phone: ${data.personalInfo.phone}
Location: ${data.personalInfo.location}

Summary:
${data.summary}

Experience:
${data.experience.map(exp => 
  `${exp.position} at ${exp.company} (${exp.startDate} - ${exp.isCurrent ? 'Present' : exp.endDate})
${exp.description}`
).join('\n\n')}

Education:
${data.education.map(edu => 
  `${edu.degree} in ${edu.field} - ${edu.institution} (${edu.startDate} - ${edu.isCurrent ? 'Present' : edu.endDate})`
).join('\n')}

Skills:
Technical: ${data.skills.technical.join(', ')}
Soft: ${data.skills.soft.join(', ')}
    `.trim();
  };

  const extractJobTitle = (jobDescription: string): string => {
    // Simple extraction - in real implementation, use AI
    const lines = jobDescription.split('\n');
    const titleLine = lines.find(line => 
      line.toLowerCase().includes('job title') || 
      line.toLowerCase().includes('position') ||
      line.length < 100 && line.trim().length > 0
    );
    return titleLine ? titleLine.replace(/^(Job Title|Position):\s*/i, '') : '';
  };

  const addExperience = () => {
    setResumeData(prev => ({
      ...prev,
      experience: [
        ...prev.experience,
        {
          id: Date.now().toString(),
          company: '',
          position: '',
          startDate: '',
          endDate: '',
          isCurrent: false,
          description: '',
        },
      ],
    }));
  };

  const addEducation = () => {
    setResumeData(prev => ({
      ...prev,
      education: [
        ...prev.education,
        {
          id: Date.now().toString(),
          institution: '',
          degree: '',
          field: '',
          startDate: '',
          endDate: '',
          isCurrent: false,
        },
      ],
    }));
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <FileText className="h-8 w-8" />
          AI Resume Builder
        </h1>
        <p className="text-muted-foreground">
          Build a professional resume with AI-powered optimization and ATS scoring
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="edit" className="flex items-center gap-2">
            <EditIcon className="h-4 w-4" />
            Edit Resume
          </TabsTrigger>
          <TabsTrigger value="optimize" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            AI Optimize
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Preview
          </TabsTrigger>
        </TabsList>

        <TabsContent value="edit" className="space-y-6">
          {/* Job Description Input */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Target Job Description
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Paste the job description you're targeting for better optimization..."
                value={jobDescription}
                onChange={(e) => setJobDescription(e.target.value)}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Personal Information */}
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={resumeData.personalInfo.name}
                  onChange={(e) => setResumeData(prev => ({
                    ...prev,
                    personalInfo: { ...prev.personalInfo, name: e.target.value }
                  }))}
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={resumeData.personalInfo.email}
                  onChange={(e) => setResumeData(prev => ({
                    ...prev,
                    personalInfo: { ...prev.personalInfo, email: e.target.value }
                  }))}
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  value={resumeData.personalInfo.phone}
                  onChange={(e) => setResumeData(prev => ({
                    ...prev,
                    personalInfo: { ...prev.personalInfo, phone: e.target.value }
                  }))}
                />
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={resumeData.personalInfo.location}
                  onChange={(e) => setResumeData(prev => ({
                    ...prev,
                    personalInfo: { ...prev.personalInfo, location: e.target.value }
                  }))}
                />
              </div>
            </CardContent>
          </Card>

          {/* Professional Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Professional Summary
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleGenerateSummary}
                  className="flex items-center gap-2"
                >
                  <Wand2 className="h-4 w-4" />
                  AI Generate
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiSuggestions.summary && (
                <Alert>
                  <Sparkles className="h-4 w-4" />
                  <AlertDescription>
                    <strong>AI Suggestion:</strong> {aiSuggestions.summary}
                    <Button
                      variant="link"
                      size="sm"
                      onClick={() => {
                        setResumeData(prev => ({ ...prev, summary: aiSuggestions.summary }));
                        setAiSuggestions(prev => ({ ...prev, summary: '' }));
                      }}
                    >
                      Use This
                    </Button>
                  </AlertDescription>
                </Alert>
              )}
              <Textarea
                placeholder="Write a compelling professional summary..."
                value={resumeData.summary}
                onChange={(e) => setResumeData(prev => ({ ...prev, summary: e.target.value }))}
                rows={4}
              />
            </CardContent>
          </Card>

          {/* Experience */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5" />
                  Work Experience
                </span>
                <Button onClick={addExperience} size="sm">
                  Add Experience
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {resumeData.experience.map((exp) => (
                <div key={exp.id} className="border rounded-lg p-4 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      placeholder="Company"
                      value={exp.company}
                      onChange={(e) => {
                        const updated = resumeData.experience.map(x =>
                          x.id === exp.id ? { ...x, company: e.target.value } : x
                        );
                        setResumeData(prev => ({ ...prev, experience: updated }));
                      }}
                    />
                    <Input
                      placeholder="Position"
                      value={exp.position}
                      onChange={(e) => {
                        const updated = resumeData.experience.map(x =>
                          x.id === exp.id ? { ...x, position: e.target.value } : x
                        );
                        setResumeData(prev => ({ ...prev, experience: updated }));
                      }}
                    />
                  </div>
                  <Textarea
                    placeholder="Job description and achievements..."
                    value={exp.description}
                    onChange={(e) => {
                      const updated = resumeData.experience.map(x =>
                        x.id === exp.id ? { ...x, description: e.target.value } : x
                      );
                      setResumeData(prev => ({ ...prev, experience: updated }));
                    }}
                    rows={3}
                  />
                  {aiSuggestions[`experience-${exp.id}`] && (
                    <Alert>
                      <Sparkles className="h-4 w-4" />
                      <AlertDescription>
                        <strong>AI Optimized:</strong> {aiSuggestions[`experience-${exp.id}`]}
                        <Button
                          variant="link"
                          size="sm"
                          onClick={() => {
                            const updated = resumeData.experience.map(x =>
                              x.id === exp.id ? { ...x, description: aiSuggestions[`experience-${exp.id}`] } : x
                            );
                            setResumeData(prev => ({ ...prev, experience: updated }));
                            setAiSuggestions(prev => ({ ...prev, [`experience-${exp.id}`]: '' }));
                          }}
                        >
                          Use This
                        </Button>
                      </AlertDescription>
                    </Alert>
                  )}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOptimizeExperience(exp.id, exp.description)}
                    >
                      <Wand2 className="h-4 w-4 mr-1" />
                      Optimize
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleExtractSkills(exp.description)}
                    >
                      <Brain className="h-4 w-4 mr-1" />
                      Extract Skills
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Skills
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Technical Skills</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {resumeData.skills.technical.map((skill, index) => (
                    <Badge key={index} variant="secondary">
                      {skill}
                      <button
                        onClick={() => {
                          const updated = resumeData.skills.technical.filter((_, i) => i !== index);
                          setResumeData(prev => ({
                            ...prev,
                            skills: { ...prev.skills, technical: updated }
                          }));
                        }}
                        className="ml-2 text-xs"
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <Label>Soft Skills</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {resumeData.skills.soft.map((skill, index) => (
                    <Badge key={index} variant="secondary">
                      {skill}
                      <button
                        onClick={() => {
                          const updated = resumeData.skills.soft.filter((_, i) => i !== index);
                          setResumeData(prev => ({
                            ...prev,
                            skills: { ...prev.skills, soft: updated }
                          }));
                        }}
                        className="ml-2 text-xs"
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button
              onClick={handleAnalyzeResume}
              disabled={isAnalyzing}
              className="flex items-center gap-2"
            >
              {isAnalyzing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4" />
                  Analyze Resume
                </>
              )}
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Save className="h-4 w-4" />
              Save Draft
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="optimize" className="space-y-6">
          {analysis ? (
            <>
              {/* Overall Score */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Resume Analysis Results
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">
                      {analysis.overallScore}/100
                    </div>
                    <Progress value={analysis.overallScore} className="mt-2" />
                    <p className="text-sm text-muted-foreground mt-1">
                      Overall Resume Score
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* ATS Optimization */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    ATS Optimization
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>ATS Score</span>
                    <Badge variant={analysis.atsOptimization.score > 70 ? 'default' : 'secondary'}>
                      {analysis.atsOptimization.score}/100
                    </Badge>
                  </div>
                  <Progress value={analysis.atsOptimization.score} />
                  
                  {analysis.atsOptimization.suggestions.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Suggestions:</h4>
                      <ul className="space-y-1">
                        {analysis.atsOptimization.suggestions.map((suggestion, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            {suggestion}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {analysis.atsOptimization.missingKeywords.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Missing Keywords:</h4>
                      <div className="flex flex-wrap gap-1">
                        {analysis.atsOptimization.missingKeywords.map((keyword, index) => (
                          <Badge key={index} variant="outline">
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Section Analysis */}
              <div className="grid md:grid-cols-2 gap-4">
                {Object.entries(analysis.sections).map(([section, data]) => (
                  <Card key={section}>
                    <CardHeader>
                      <CardTitle className="capitalize">{section}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground">{data.content}</p>
                      {data.suggestions.length > 0 && (
                        <div>
                          <h5 className="font-medium text-sm mb-1">Suggestions:</h5>
                          <ul className="space-y-1">
                            {data.suggestions.map((suggestion, index) => (
                              <li key={index} className="text-xs flex items-start gap-1">
                                <span className="text-blue-500">•</span>
                                {suggestion}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Ready to Optimize</h3>
                <p className="text-muted-foreground mb-4">
                  Analyze your resume to get AI-powered optimization suggestions and ATS scoring.
                </p>
                <Button onClick={() => setActiveTab('edit')}>
                  Go to Editor
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>Resume Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-white p-8 rounded-lg shadow-sm border">
                <pre className="whitespace-pre-wrap font-sans text-sm">
                  {generateResumeText(resumeData)}
                </pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}