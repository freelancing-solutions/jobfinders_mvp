import { NextRequest, NextResponse } from 'next/server';
import { aiService } from '@/services/ai-service';
import { resumeBuilderService } from '@/services/resume-builder';
import { atsSystem } from '@/services/ats-system';
import { matchingEngine } from '@/services/matching-engine';
import { aiAgentSystem } from '@/services/ai-agents';

export async function POST(req: NextRequest) {
  try {
    const { type, params } = await req.json();

    // Check if AI service is available
    const isAvailable = await aiService.isAvailable();
    if (!isAvailable) {
      return NextResponse.json(
        { error: 'AI service is currently unavailable' },
        { status: 503 }
      );
    }

    switch (type) {
      // Resume Builder Services
      case 'analyze-resume':
        const analysis = await resumeBuilderService.analyzeResume(
          params.resumeText,
          params.jobDescription
        );
        return NextResponse.json(analysis);

      case 'generate-summary':
        const summary = await resumeBuilderService.generateSummary(
          params.experience,
          params.skills,
          params.targetRole
        );
        return NextResponse.json({ summary });

      case 'optimize-experience':
        const optimized = await resumeBuilderService.optimizeExperience(
          params.originalDescription,
          params.targetRole
        );
        return NextResponse.json({ optimized });

      case 'extract-skills':
        const skills = await resumeBuilderService.extractSkills(params.text);
        return NextResponse.json(skills);

      case 'generate-cover-letter':
        const coverLetter = await resumeBuilderService.generateCoverLetter(
          params.resumeText,
          params.jobDescription,
          params.companyName
        );
        return NextResponse.json({ coverLetter });

      case 'get-resume-templates':
        const templates = await resumeBuilderService.getResumeTemplates();
        return NextResponse.json(templates);

      // ATS System Services
      case 'ats-analyze':
        const atsResult = await atsSystem.analyzeResumeMatch(
          params.resumeText,
          params.jobDescription,
          params.requirements
        );
        return NextResponse.json(atsResult);

      case 'extract-requirements':
        const requirements = await atsSystem.extractJobRequirements(params.jobDescription);
        return NextResponse.json(requirements);

      case 'optimize-resume-ats':
        const optimizedResume = await atsSystem.optimizeResumeForATS(
          params.resumeText,
          params.jobDescription,
          params.targetKeywords
        );
        return NextResponse.json({ optimizedResume });

      case 'keyword-suggestions':
        const keywords = await atsSystem.generateKeywordSuggestions(
          params.jobDescription,
          params.industry
        );
        return NextResponse.json(keywords);

      case 'calculate-match-score':
        const matchScore = await atsSystem.calculateMatchScore(
          params.resumeText,
          params.jobDescription
        );
        return NextResponse.json(matchScore);

      // Matching Engine Services
      case 'match-candidate-to-job':
        const matchResult = await matchingEngine.matchCandidateToJob(
          params.candidate,
          params.job,
          params.config
        );
        return NextResponse.json(matchResult);

      case 'find-top-matches':
        const topMatches = await matchingEngine.findTopMatches(
          params.candidate,
          params.jobs,
          params.limit
        );
        return NextResponse.json(topMatches);

      // AI Agent Services
      case 'career-advice':
        const careerAdvice = await aiAgentSystem.getCareerAdvice(params);
        return NextResponse.json(careerAdvice);

      case 'interview-prep':
        const interviewPrep = await aiAgentSystem.prepareInterview(params);
        return NextResponse.json(interviewPrep);

      case 'salary-negotiation':
        const salaryAdvice = await aiAgentSystem.getSalaryNegotiationAdvice(params);
        return NextResponse.json(salaryAdvice);

      case 'job-recommendations':
        const jobRecommendations = await aiAgentSystem.generateJobRecommendations(params);
        return NextResponse.json(jobRecommendations);

      case 'resume-feedback':
        const resumeFeedback = await aiAgentSystem.provideResumeFeedback(params);
        return NextResponse.json(resumeFeedback);

      // General AI Services
      case 'analyze-text':
        const textAnalysis = await aiService.analyzeText(
          params.text,
          params.analysisType
        );
        return NextResponse.json(textAnalysis);

      case 'generate-text':
        const generatedText = await aiService.generateText(
          params.prompt,
          params.config
        );
        return NextResponse.json(generatedText);

      case 'generate-json':
        const generatedJson = await aiService.generateJSON(
          params.prompt,
          params.config
        );
        return NextResponse.json(generatedJson);

      default:
        return NextResponse.json(
          { error: 'Invalid AI service type' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('AI API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'AI Service API is running',
    services: [
      'resume-builder',
      'ats-system',
      'matching-engine',
      'ai-agents',
      'general-ai'
    ],
    endpoints: [
      'analyze-resume',
      'generate-summary',
      'optimize-experience',
      'extract-skills',
      'generate-cover-letter',
      'get-resume-templates',
      'ats-analyze',
      'extract-requirements',
      'optimize-resume-ats',
      'keyword-suggestions',
      'calculate-match-score',
      'match-candidate-to-job',
      'find-top-matches',
      'career-advice',
      'interview-prep',
      'salary-negotiation',
      'job-recommendations',
      'resume-feedback',
      'analyze-text',
      'generate-text',
      'generate-json'
    ]
  });
}