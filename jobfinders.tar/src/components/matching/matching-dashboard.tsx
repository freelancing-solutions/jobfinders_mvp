'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Users, 
  Search, 
  Brain, 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle,
  Target,
  Star,
  Filter,
  RefreshCw,
  Eye,
  MessageSquare
} from 'lucide-react';

interface CandidateProfile {
  id: string;
  name: string;
  email: string;
  skills: string[];
  experience: number;
  experienceLevel: 'entry' | 'mid' | 'senior' | 'executive';
  location: string;
  salaryExpectation: { min: number; max: number; currency: string };
  industry: string;
  jobTitles: string[];
  education: { degree: string; field: string };
  preferences: {
    remoteWork: boolean;
    relocation: boolean;
    workType: 'full-time' | 'part-time' | 'contract' | 'internship';
  };
  matchScore?: number;
  status?: 'new' | 'contacted' | 'interviewed' | 'hired' | 'rejected';
}

interface JobProfile {
  id: string;
  title: string;
  description: string;
  company: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experience: { min: number; level: 'entry' | 'mid' | 'senior' | 'executive' };
  location: string;
  salary: { min: number; max: number; currency: string };
  industry: string;
  type: 'full-time' | 'part-time' | 'contract' | 'internship';
  remoteAllowed: boolean;
  status: 'active' | 'closed' | 'paused';
  applicantsCount: number;
}

interface MatchResult {
  candidateId: string;
  jobId: string;
  overallScore: number;
  breakdown: {
    skillsMatch: number;
    experienceMatch: number;
    locationMatch: number;
    salaryMatch: number;
    cultureFit: number;
    educationMatch: number;
  };
  strengths: string[];
  concerns: string[];
  recommendation: 'strong' | 'good' | 'moderate' | 'weak';
  explanation: string;
}

export function MatchingDashboard() {
  const [candidates, setCandidates] = useState<CandidateProfile[]>([]);
  const [jobs, setJobs] = useState<JobProfile[]>([]);
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const [selectedJob, setSelectedJob] = useState<JobProfile | null>(null);
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateProfile | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [filters, setFilters] = useState({
    minScore: 50,
    recommendation: 'all' as 'all' | 'strong' | 'good' | 'moderate',
    status: 'all' as 'all' | 'new' | 'contacted' | 'interviewed' | 'hired' | 'rejected'
  });

  // Mock data for demonstration
  useEffect(() => {
    // Mock candidates data
    const mockCandidates: CandidateProfile[] = [
      {
        id: '1',
        name: 'Sarah Johnson',
        email: 'sarah.johnson@email.com',
        skills: ['JavaScript', 'React', 'Node.js', 'TypeScript', 'Python'],
        experience: 5,
        experienceLevel: 'mid',
        location: 'San Francisco, CA',
        salaryExpectation: { min: 90000, max: 120000, currency: 'USD' },
        industry: 'Technology',
        jobTitles: ['Frontend Developer', 'Full Stack Developer'],
        education: { degree: 'Bachelor', field: 'Computer Science' },
        preferences: {
          remoteWork: true,
          relocation: false,
          workType: 'full-time'
        }
      },
      {
        id: '2',
        name: 'Michael Chen',
        email: 'michael.chen@email.com',
        skills: ['Java', 'Spring Boot', 'AWS', 'Docker', 'Kubernetes'],
        experience: 8,
        experienceLevel: 'senior',
        location: 'Seattle, WA',
        salaryExpectation: { min: 120000, max: 150000, currency: 'USD' },
        industry: 'Technology',
        jobTitles: ['Senior Software Engineer', 'Backend Developer'],
        education: { degree: 'Master', field: 'Software Engineering' },
        preferences: {
          remoteWork: true,
          relocation: true,
          workType: 'full-time'
        }
      },
      {
        id: '3',
        name: 'Emily Rodriguez',
        email: 'emily.rodriguez@email.com',
        skills: ['Python', 'Machine Learning', 'TensorFlow', 'Data Analysis', 'SQL'],
        experience: 3,
        experienceLevel: 'mid',
        location: 'Austin, TX',
        salaryExpectation: { min: 80000, max: 100000, currency: 'USD' },
        industry: 'Technology',
        jobTitles: ['Data Scientist', 'ML Engineer'],
        education: { degree: 'Master', field: 'Data Science' },
        preferences: {
          remoteWork: true,
          relocation: false,
          workType: 'full-time'
        }
      }
    ];

    // Mock jobs data
    const mockJobs: JobProfile[] = [
      {
        id: '1',
        title: 'Senior Frontend Developer',
        description: 'We are looking for a senior frontend developer with React expertise...',
        company: 'TechCorp Inc.',
        requiredSkills: ['JavaScript', 'React', 'TypeScript'],
        preferredSkills: ['Node.js', 'GraphQL', 'AWS'],
        experience: { min: 4, level: 'senior' },
        location: 'San Francisco, CA',
        salary: { min: 100000, max: 140000, currency: 'USD' },
        industry: 'Technology',
        type: 'full-time',
        remoteAllowed: true,
        status: 'active',
        applicantsCount: 15
      },
      {
        id: '2',
        title: 'Full Stack Engineer',
        description: 'Join our team as a full stack engineer working on cutting-edge projects...',
        company: 'StartupXYZ',
        requiredSkills: ['JavaScript', 'Python', 'React'],
        preferredSkills: ['Node.js', 'PostgreSQL', 'Docker'],
        experience: { min: 3, level: 'mid' },
        location: 'Remote',
        salary: { min: 80000, max: 110000, currency: 'USD' },
        industry: 'Technology',
        type: 'full-time',
        remoteAllowed: true,
        status: 'active',
        applicantsCount: 23
      },
      {
        id: '3',
        title: 'Data Scientist',
        description: 'Looking for a data scientist to join our analytics team...',
        company: 'DataTech Solutions',
        requiredSkills: ['Python', 'Machine Learning', 'SQL'],
        preferredSkills: ['TensorFlow', 'PyTorch', 'Data Visualization'],
        experience: { min: 2, level: 'mid' },
        location: 'Austin, TX',
        salary: { min: 90000, max: 130000, currency: 'USD' },
        industry: 'Technology',
        type: 'full-time',
        remoteAllowed: true,
        status: 'active',
        applicantsCount: 8
      }
    ];

    setCandidates(mockCandidates);
    setJobs(mockJobs);

    // Generate mock matches
    const mockMatches: MatchResult[] = [
      {
        candidateId: '1',
        jobId: '1',
        overallScore: 85,
        breakdown: {
          skillsMatch: 90,
          experienceMatch: 80,
          locationMatch: 100,
          salaryMatch: 85,
          cultureFit: 75,
          educationMatch: 90
        },
        strengths: [
          'Strong React and JavaScript skills',
          'Perfect location match',
          'Relevant experience level',
          'Good educational background'
        ],
        concerns: [
          'Salary expectation slightly above range',
          'Limited backend experience'
        ],
        recommendation: 'strong',
        explanation: 'Sarah is an excellent match for this position with strong technical skills and perfect location alignment.'
      },
      {
        candidateId: '2',
        jobId: '2',
        overallScore: 92,
        breakdown: {
          skillsMatch: 95,
          experienceMatch: 90,
          locationMatch: 100,
          salaryMatch: 80,
          cultureFit: 85,
          educationMatch: 95
        },
        strengths: [
          'Extensive full-stack experience',
          'Strong cloud and DevOps skills',
          'Open to relocation',
          'Advanced degree'
        ],
        concerns: [
          'Salary expectation at top of range',
          'May be overqualified for role'
        ],
        recommendation: 'strong',
        explanation: 'Michael brings comprehensive full-stack expertise and leadership experience to the role.'
      },
      {
        candidateId: '3',
        jobId: '3',
        overallScore: 88,
        breakdown: {
          skillsMatch: 95,
          experienceMatch: 85,
          locationMatch: 100,
          salaryMatch: 90,
          cultureFit: 90,
          educationMatch: 95
        },
        strengths: [
          'Perfect ML and data science skills',
          'Ideal location match',
          'Advanced degree in relevant field',
          'Strong academic background'
        ],
        concerns: [
          'Limited professional experience',
          'May need mentorship'
        ],
        recommendation: 'strong',
        explanation: 'Emily has the perfect skill set and educational background for this data science role.'
      }
    ];

    setMatches(mockMatches);
    setSelectedJob(mockJobs[0]);
  }, []);

  const handleAnalyzeMatch = async (candidateId: string, jobId: string) => {
    setIsAnalyzing(true);
    try {
      const candidate = candidates.find(c => c.id === candidateId);
      const job = jobs.find(j => j.id === jobId);

      if (!candidate || !job) return;

      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'match-candidate-to-job',
          params: {
            candidate,
            job
          }
        }),
      });

      if (response.ok) {
        const matchResult = await response.json();
        // Update matches array
        setMatches(prev => {
          const filtered = prev.filter(m => !(m.candidateId === candidateId && m.jobId === jobId));
          return [...filtered, matchResult];
        });
      }
    } catch (error) {
      console.error('Failed to analyze match:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case 'strong': return 'text-green-600 bg-green-100';
      case 'good': return 'text-blue-600 bg-blue-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'weak': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const filteredMatches = matches.filter(match => {
    if (match.overallScore < filters.minScore) return false;
    if (filters.recommendation !== 'all' && match.recommendation !== filters.recommendation) return false;
    return true;
  });

  const getCandidateForMatch = (candidateId: string) => {
    return candidates.find(c => c.id === candidateId);
  };

  const getJobForMatch = (jobId: string) => {
    return jobs.find(j => j.id === jobId);
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Users className="h-8 w-8" />
          AI Candidate Matching
        </h1>
        <p className="text-muted-foreground">
          Intelligent matching powered by AI to find the perfect candidate-job fit
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="matches" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Matches
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            {/* Stats Cards */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Matches</p>
                    <p className="text-2xl font-bold">{matches.length}</p>
                  </div>
                  <Users className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Strong Matches</p>
                    <p className="text-2xl font-bold">
                      {matches.filter(m => m.recommendation === 'strong').length}
                    </p>
                  </div>
                  <Star className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Match Score</p>
                    <p className="text-2xl font-bold">
                      {matches.length > 0 ? Math.round(matches.reduce((sum, m) => sum + m.overallScore, 0) / matches.length) : 0}%
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Matches */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  Top Matches
                </span>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Refresh
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredMatches
                  .sort((a, b) => b.overallScore - a.overallScore)
                  .slice(0, 5)
                  .map((match, index) => {
                    const candidate = getCandidateForMatch(match.candidateId);
                    const job = getJobForMatch(match.jobId);
                    
                    if (!candidate || !job) return null;

                    return (
                      <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="font-medium">{candidate.name}</h3>
                              <Badge className={getRecommendationColor(match.recommendation)}>
                                {match.recommendation}
                              </Badge>
                              <span className={`text-lg font-bold ${getScoreColor(match.overallScore)}`}>
                                {match.overallScore}%
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {candidate.jobTitles.join(', ')} • {candidate.location}
                            </p>
                            <p className="text-sm text-muted-foreground mb-3">
                              Matched with: <span className="font-medium">{job.title}</span> at {job.company}
                            </p>
                            <div className="flex flex-wrap gap-1 mb-3">
                              {candidate.skills.slice(0, 5).map((skill, skillIndex) => (
                                <Badge key={skillIndex} variant="outline" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex gap-2 ml-4">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <MessageSquare className="h-4 w-4 mr-1" />
                              Contact
                            </Button>
                          </div>
                        </div>
                        
                        {/* Match Breakdown */}
                        <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t">
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground">Skills</p>
                            <p className={`text-sm font-medium ${getScoreColor(match.breakdown.skillsMatch)}`}>
                              {match.breakdown.skillsMatch}%
                            </p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground">Experience</p>
                            <p className={`text-sm font-medium ${getScoreColor(match.breakdown.experienceMatch)}`}>
                              {match.breakdown.experienceMatch}%
                            </p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground">Location</p>
                            <p className={`text-sm font-medium ${getScoreColor(match.breakdown.locationMatch)}`}>
                              {match.breakdown.locationMatch}%
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="matches" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium">Minimum Score</label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={filters.minScore}
                    onChange={(e) => setFilters(prev => ({ ...prev, minScore: parseInt(e.target.value) }))}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0%</span>
                    <span>{filters.minScore}%</span>
                    <span>100%</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium">Recommendation</label>
                  <select
                    value={filters.recommendation}
                    onChange={(e) => setFilters(prev => ({ ...prev, recommendation: e.target.value as any }))}
                    className="w-full p-2 border rounded-md"
                  >
                    <option value="all">All</option>
                    <option value="strong">Strong</option>
                    <option value="good">Good</option>
                    <option value="moderate">Moderate</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm font-medium">Job</label>
                  <select
                    value={selectedJob?.id || ''}
                    onChange={(e) => setSelectedJob(jobs.find(j => j.id === e.target.value) || null)}
                    className="w-full p-2 border rounded-md"
                  >
                    <option value="">All Jobs</option>
                    {jobs.map(job => (
                      <option key={job.id} value={job.id}>
                        {job.title} - {job.company}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Matches List */}
          <div className="space-y-4">
            {filteredMatches
              .filter(match => !selectedJob || match.jobId === selectedJob.id)
              .sort((a, b) => b.overallScore - a.overallScore)
              .map((match, index) => {
                const candidate = getCandidateForMatch(match.candidateId);
                const job = getJobForMatch(match.jobId);
                
                if (!candidate || !job) return null;

                return (
                  <Card key={index}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-medium">{candidate.name}</h3>
                            <Badge className={getRecommendationColor(match.recommendation)}>
                              {match.recommendation.toUpperCase()}
                            </Badge>
                            <span className={`text-xl font-bold ${getScoreColor(match.overallScore)}`}>
                              {match.overallScore}% Match
                            </span>
                          </div>
                          
                          <div className="grid md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <h4 className="font-medium text-sm mb-1">Candidate</h4>
                              <p className="text-sm text-muted-foreground">
                                {candidate.jobTitles.join(', ')} • {candidate.experience} years experience
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {candidate.location} • {candidate.salaryExpectation.currency} {candidate.salaryExpectation.min}-{candidate.salaryExpectation.max}
                              </p>
                              <div className="flex flex-wrap gap-1 mt-2">
                                {candidate.skills.slice(0, 6).map((skill, skillIndex) => (
                                  <Badge key={skillIndex} variant="outline" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            
                            <div>
                              <h4 className="font-medium text-sm mb-1">Job</h4>
                              <p className="text-sm text-muted-foreground">
                                {job.title} • {job.company}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {job.location} • {job.salary.currency} {job.salary.min}-{job.salary.max}
                              </p>
                              <div className="flex flex-wrap gap-1 mt-2">
                                {job.requiredSkills.slice(0, 4).map((skill, skillIndex) => (
                                  <Badge key={skillIndex} variant="secondary" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            Contact
                          </Button>
                        </div>
                      </div>
                      
                      {/* Match Breakdown */}
                      <div className="border-t pt-4">
                        <h4 className="font-medium text-sm mb-3">Match Breakdown</h4>
                        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                          {Object.entries(match.breakdown).map(([key, score]) => (
                            <div key={key} className="text-center">
                              <p className="text-xs text-muted-foreground capitalize">
                                {key.replace('Match', '').replace('Fit', 'Culture')}
                              </p>
                              <Progress value={score} className="mt-1 h-2" />
                              <p className={`text-xs font-medium mt-1 ${getScoreColor(score)}`}>
                                {score}%
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Strengths and Concerns */}
                      <div className="grid md:grid-cols-2 gap-4 mt-4">
                        {match.strengths.length > 0 && (
                          <div>
                            <h5 className="font-medium text-sm mb-2 text-green-600">Strengths</h5>
                            <ul className="space-y-1">
                              {match.strengths.slice(0, 3).map((strength, strengthIndex) => (
                                <li key={strengthIndex} className="text-xs flex items-start gap-1">
                                  <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                                  {strength}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {match.concerns.length > 0 && (
                          <div>
                            <h5 className="font-medium text-sm mb-2 text-orange-600">Considerations</h5>
                            <ul className="space-y-1">
                              {match.concerns.slice(0, 3).map((concern, concernIndex) => (
                                <li key={concernIndex} className="text-xs flex items-start gap-1">
                                  <AlertTriangle className="h-3 w-3 text-orange-500 mt-0.5 flex-shrink-0" />
                                  {concern}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground mt-3 italic">
                        {match.explanation}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Recommendation Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Match Quality Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {['strong', 'good', 'moderate', 'weak'].map(recommendation => {
                    const count = matches.filter(m => m.recommendation === recommendation).length;
                    const percentage = matches.length > 0 ? (count / matches.length) * 100 : 0;
                    
                    return (
                      <div key={recommendation}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="capitalize">{recommendation}</span>
                          <span>{count} ({percentage.toFixed(1)}%)</span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Score Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Score Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { range: '90-100%', min: 90, max: 100 },
                    { range: '80-89%', min: 80, max: 89 },
                    { range: '70-79%', min: 70, max: 79 },
                    { range: '60-69%', min: 60, max: 69 },
                    { range: 'Below 60%', min: 0, max: 59 }
                  ].map(({ range, min, max }) => {
                    const count = matches.filter(m => m.overallScore >= min && m.overallScore <= max).length;
                    const percentage = matches.length > 0 ? (count / matches.length) * 100 : 0;
                    
                    return (
                      <div key={range}>
                        <div className="flex justify-between text-sm mb-1">
                          <span>{range}</span>
                          <span>{count} ({percentage.toFixed(1)}%)</span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Skills */}
          <Card>
            <CardHeader>
              <CardTitle>Most In-Demand Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {['JavaScript', 'Python', 'React', 'Node.js', 'AWS', 'Machine Learning', 'Java', 'TypeScript'].map((skill, index) => (
                  <div key={index} className="text-center">
                    <Badge variant="outline" className="mb-1">
                      {skill}
                    </Badge>
                    <p className="text-xs text-muted-foreground">
                      {Math.floor(Math.random() * 20) + 5} matches
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}