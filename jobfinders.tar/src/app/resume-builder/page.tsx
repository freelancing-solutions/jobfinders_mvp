import { ResumeBuilder } from '@/components/resume/resume-builder';

export default function ResumeBuilderPage() {
  return <ResumeBuilder />;
}