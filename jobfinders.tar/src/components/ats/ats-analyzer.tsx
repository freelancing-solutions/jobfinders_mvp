'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Target, 
  FileText, 
  Brain, 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle,
  Upload,
  Download,
  Eye,
  BarChart3
} from 'lucide-react';

interface ATSAnalysisResult {
  score: number;
  breakdown: {
    keywords: {
      score: number;
      matched: string[];
      missing: string[];
      partial: string[];
    };
    experience: {
      score: number;
      yearsMatch: boolean;
      levelMatch: boolean;
    };
    skills: {
      score: number;
      matched: string[];
      missing: string[];
      proficiency: { [key: string]: string };
    };
    education: {
      score: number;
      degreeMatch: boolean;
      fieldMatch: boolean;
    };
    format: {
      score: number;
      issues: string[];
      suggestions: string[];
    };
  };
  suggestions: string[];
  ranking: 'excellent' | 'good' | 'fair' | 'poor';
  confidence: number;
}

interface JobRequirements {
  title: string;
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experience: { minYears: number; level: string };
  education: { degree: string; field?: string };
  keywords: string[];
}

export function ATSAnalyzer() {
  const [resumeText, setResumeText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [analysis, setAnalysis] = useState<ATSAnalysisResult | null>(null);
  const [requirements, setRequirements] = useState<JobRequirements | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeTab, setActiveTab] = useState('analyzer');

  const handleAnalyze = async () => {
    if (!resumeText.trim() || !jobDescription.trim()) {
      alert('Please provide both resume text and job description');
      return;
    }

    setIsAnalyzing(true);
    try {
      // First, extract requirements from job description
      const requirementsResponse = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'extract-requirements',
          params: { jobDescription },
        }),
      });

      if (requirementsResponse.ok) {
        const reqData = await requirementsResponse.json();
        setRequirements(reqData);
      }

      // Then analyze the resume match
      const analysisResponse = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'ats-analyze',
          params: {
            resumeText,
            jobDescription,
            requirements: requirements || undefined,
          },
        }),
      });

      if (analysisResponse.ok) {
        const analysisData = await analysisResponse.json();
        setAnalysis(analysisData);
      }
    } catch (error) {
      console.error('Failed to analyze ATS match:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleOptimizeResume = async () => {
    if (!resumeText.trim() || !jobDescription.trim()) {
      alert('Please provide both resume text and job description');
      return;
    }

    try {
      const targetKeywords = requirements?.keywords || [];
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'optimize-resume-ats',
          params: {
            resumeText,
            jobDescription,
            targetKeywords,
          },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setResumeText(result.optimizedResume);
      }
    } catch (error) {
      console.error('Failed to optimize resume:', error);
    }
  };

  const getRankingColor = (ranking: string) => {
    switch (ranking) {
      case 'excellent': return 'text-green-600 bg-green-100';
      case 'good': return 'text-blue-600 bg-blue-100';
      case 'fair': return 'text-yellow-600 bg-yellow-100';
      case 'poor': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Target className="h-8 w-8" />
          ATS Resume Analyzer
        </h1>
        <p className="text-muted-foreground">
          Optimize your resume to pass Applicant Tracking Systems and land more interviews
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="analyzer" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            ATS Analyzer
          </TabsTrigger>
          <TabsTrigger value="optimizer" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Resume Optimizer
          </TabsTrigger>
          <TabsTrigger value="keywords" className="flex items-center gap-2">
            Keywords
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analyzer" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Input Section */}
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Your Resume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder="Paste your resume text here..."
                    value={resumeText}
                    onChange={(e) => setResumeText(e.target.value)}
                    rows={12}
                    className="resize-none"
                  />
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm" className="flex items-center gap-2">
                      <Upload className="h-4 w-4" />
                      Upload File
                    </Button>
                    <Button variant="outline" size="sm" className="flex items-center gap-2">
                      <Download className="h-4 w-4" />
                      Download Template
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Job Description
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder="Paste the job description here..."
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    rows={8}
                    className="resize-none"
                  />
                </CardContent>
              </Card>

              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing || !resumeText.trim() || !jobDescription.trim()}
                className="w-full flex items-center gap-2"
                size="lg"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="h-4 w-4" />
                    Analyze ATS Match
                  </>
                )}
              </Button>
            </div>

            {/* Results Section */}
            <div className="space-y-4">
              {analysis ? (
                <>
                  {/* Overall Score */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <TrendingUp className="h-5 w-5" />
                          ATS Analysis Results
                        </span>
                        <Badge className={getRankingColor(analysis.ranking)}>
                          {analysis.ranking.toUpperCase()}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-center">
                        <div className={`text-4xl font-bold ${getScoreColor(analysis.score)}`}>
                          {analysis.score}/100
                        </div>
                        <Progress value={analysis.score} className="mt-2" />
                        <p className="text-sm text-muted-foreground mt-1">
                          Confidence: {Math.round(analysis.confidence * 100)}%
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Detailed Breakdown */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Detailed Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Keywords */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Keywords Match</span>
                          <span className={`font-bold ${getScoreColor(analysis.breakdown.keywords.score)}`}>
                            {analysis.breakdown.keywords.score}%
                          </span>
                        </div>
                        <Progress value={analysis.breakdown.keywords.score} className="mb-2" />
                        
                        {analysis.breakdown.keywords.matched.length > 0 && (
                          <div className="mb-2">
                            <p className="text-sm font-medium text-green-600 mb-1">Matched:</p>
                            <div className="flex flex-wrap gap-1">
                              {analysis.breakdown.keywords.matched.slice(0, 8).map((keyword, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {keyword}
                                </Badge>
                              ))}
                              {analysis.breakdown.keywords.matched.length > 8 && (
                                <Badge variant="outline" className="text-xs">
                                  +{analysis.breakdown.keywords.matched.length - 8} more
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {analysis.breakdown.keywords.missing.length > 0 && (
                          <div>
                            <p className="text-sm font-medium text-red-600 mb-1">Missing:</p>
                            <div className="flex flex-wrap gap-1">
                              {analysis.breakdown.keywords.missing.slice(0, 8).map((keyword, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {keyword}
                                </Badge>
                              ))}
                              {analysis.breakdown.keywords.missing.length > 8 && (
                                <Badge variant="outline" className="text-xs">
                                  +{analysis.breakdown.keywords.missing.length - 8} more
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Experience */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Experience Match</span>
                          <span className={`font-bold ${getScoreColor(analysis.breakdown.experience.score)}`}>
                            {analysis.breakdown.experience.score}%
                          </span>
                        </div>
                        <Progress value={analysis.breakdown.experience.score} />
                        <div className="flex gap-4 mt-2 text-xs">
                          <span className={analysis.breakdown.experience.yearsMatch ? 'text-green-600' : 'text-red-600'}>
                            ✓ Years Match
                          </span>
                          <span className={analysis.breakdown.experience.levelMatch ? 'text-green-600' : 'text-red-600'}>
                            ✓ Level Match
                          </span>
                        </div>
                      </div>

                      {/* Skills */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Skills Match</span>
                          <span className={`font-bold ${getScoreColor(analysis.breakdown.skills.score)}`}>
                            {analysis.breakdown.skills.score}%
                          </span>
                        </div>
                        <Progress value={analysis.breakdown.skills.score} />
                      </div>

                      {/* Education */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Education Match</span>
                          <span className={`font-bold ${getScoreColor(analysis.breakdown.education.score)}`}>
                            {analysis.breakdown.education.score}%
                          </span>
                        </div>
                        <Progress value={analysis.breakdown.education.score} />
                        <div className="flex gap-4 mt-2 text-xs">
                          <span className={analysis.breakdown.education.degreeMatch ? 'text-green-600' : 'text-red-600'}>
                            ✓ Degree Match
                          </span>
                          <span className={analysis.breakdown.education.fieldMatch ? 'text-green-600' : 'text-red-600'}>
                            ✓ Field Match
                          </span>
                        </div>
                      </div>

                      {/* Format */}
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Format Score</span>
                          <span className={`font-bold ${getScoreColor(analysis.breakdown.format.score)}`}>
                            {analysis.breakdown.format.score}%
                          </span>
                        </div>
                        <Progress value={analysis.breakdown.format.score} />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Suggestions */}
                  {analysis.suggestions.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <CheckCircle className="h-5 w-5" />
                          Improvement Suggestions
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {analysis.suggestions.map((suggestion, index) => (
                            <li key={index} className="flex items-start gap-2 text-sm">
                              <CheckCircle className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                              {suggestion}
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}
                </>
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Ready to Analyze</h3>
                    <p className="text-muted-foreground">
                      Paste your resume and a job description to get a detailed ATS analysis.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="optimizer" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Current Resume
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  rows={16}
                  className="resize-none"
                />
                <Button
                  onClick={handleOptimizeResume}
                  disabled={!resumeText.trim() || !jobDescription.trim()}
                  className="w-full mt-4 flex items-center gap-2"
                >
                  <Brain className="h-4 w-4" />
                  Optimize for ATS
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  Optimization Tips
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Pro Tip:</strong> Use the keywords from the job description naturally throughout your resume. 
                    ATS systems scan for specific terms and phrases.
                  </AlertDescription>
                </Alert>

                <div className="space-y-3">
                  <h4 className="font-medium">Best Practices:</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Use standard section headings (Experience, Education, Skills)
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Include keywords from the job description naturally
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Quantify achievements with numbers and metrics
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Use a clean, simple format without tables or columns
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      Save as a .docx or .pdf file for best compatibility
                    </li>
                  </ul>
                </div>

                {requirements && (
                  <div className="space-y-3">
                    <h4 className="font-medium">Target Keywords:</h4>
                    <div className="flex flex-wrap gap-1">
                      {requirements.keywords.slice(0, 12).map((keyword, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {keyword}
                        </Badge>
                      ))}
                      {requirements.keywords.length > 12 && (
                        <Badge variant="outline" className="text-xs">
                          +{requirements.keywords.length - 12} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="keywords" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                Keywords
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Job Description</label>
                  <Textarea
                    placeholder="Paste job description to extract keywords..."
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    rows={6}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Industry</label>
                  <input
                    type="text"
                    placeholder="e.g., Technology, Healthcare, Finance"
                    className="w-full p-2 border rounded-md"
                    value={requirements?.title || ''}
                    readOnly
                  />
                </div>
              </div>
              
              {requirements && (
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Required Skills:</h4>
                    <div className="flex flex-wrap gap-2">
                      {requirements.requiredSkills.map((skill, index) => (
                        <Badge key={index} variant="default">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Preferred Skills:</h4>
                    <div className="flex flex-wrap gap-2">
                      {requirements.preferredSkills.map((skill, index) => (
                        <Badge key={index} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">All Keywords:</h4>
                    <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto">
                      {requirements.keywords.map((keyword, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}