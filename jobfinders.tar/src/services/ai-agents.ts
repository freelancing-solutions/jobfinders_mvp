import { aiService } from './ai-service';
import { redis } from '@/lib/redis';

export interface CareerAdviceResponse {
  advice: string;
  actionItems: string[];
  resources: string[];
  nextSteps: string[];
}

export interface InterviewPreparation {
  questions: Array<{
    question: string;
    type: 'technical' | 'behavioral' | 'situational';
    difficulty: 'easy' | 'medium' | 'hard';
    sampleAnswer: string;
    tips: string[];
  }>;
  companyResearch: {
    overview: string;
    culture: string;
    recentNews: string[];
  };
  roleAnalysis: {
    keyResponsibilities: string[];
    requiredSkills: string[];
    successMetrics: string[];
  };
}

export interface SalaryNegotiationAdvice {
  marketRate: {
    min: number;
    average: number;
    max: number;
    currency: string;
  };
  negotiationStrategy: string[];
  talkingPoints: string[];
  counterOfferSuggestions: string[];
  benefitsToConsider: string[];
}

export class AIAgentSystem {
  private readonly systemPrompt = `You are an expert career coach and AI employment agent with extensive knowledge of job markets, hiring practices, and career development strategies. Your goal is to provide personalized, actionable guidance to job seekers.`;

  async getCareerAdvice(params: {
    userId: string;
    currentRole: string;
    experience: number;
    skills: string[];
    goals: string;
    challenges: string[];
    industry: string;
  }): Promise<CareerAdviceResponse> {
    const contextKey = `career:${params.userId}`;
    
    // Try to get cached advice
    if (redis) {
      try {
        const cached = await redis.get(contextKey);
        if (cached) {
          return JSON.parse(cached);
        }
      } catch (error) {
        console.log('Cache miss, generating new career advice');
      }
    }

    const prompt = `Provide personalized career advice for the following professional:

Current Role: ${params.currentRole}
Years of Experience: ${params.experience}
Skills: ${params.skills.join(', ')}
Career Goals: ${params.goals}
Current Challenges: ${params.challenges.join(', ')}
Industry: ${params.industry}

Please provide comprehensive career advice in JSON format:
{
  "advice": "detailed career advice and guidance",
  "actionItems": ["specific action item 1", "action item 2"],
  "resources": ["resource 1", "resource 2"],
  "nextSteps": ["next step 1", "next step 2"]
}

Focus on:
1. Career progression path
2. Skill development recommendations
3. Industry-specific advice
4. Addressing current challenges
5. Actionable next steps`;

    const response = await aiService.generateJSON<CareerAdviceResponse>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.7,
    });

    // Cache the response
    if (response && redis) {
      try {
        await redis.setex(contextKey, 86400, JSON.stringify(response)); // Cache for 24 hours
      } catch (error) {
        console.error('Failed to cache career advice:', error);
      }
    }

    return response || {
      advice: '',
      actionItems: [],
      resources: [],
      nextSteps: [],
    };
  }

  async prepareInterview(params: {
    jobTitle: string;
    company: string;
    industry: string;
    experience: string;
    skills: string[];
    jobDescription?: string;
  }): Promise<InterviewPreparation> {
    const prompt = `Prepare a comprehensive interview preparation guide for the following scenario:

Job Title: ${params.jobTitle}
Company: ${params.company}
Industry: ${params.industry}
Candidate Experience: ${params.experience}
Candidate Skills: ${params.skills.join(', ')}
${params.jobDescription ? `Job Description: ${params.jobDescription}` : ''}

Please provide a detailed interview preparation guide in JSON format:
{
  "questions": [
    {
      "question": "interview question",
      "type": "technical" | "behavioral" | "situational",
      "difficulty": "easy" | "medium" | "hard",
      "sampleAnswer": "sample answer",
      "tips": ["tip 1", "tip 2"]
    }
  ],
  "companyResearch": {
    "overview": "company overview",
    "culture": "company culture description",
    "recentNews": ["news item 1", "news item 2"]
  },
  "roleAnalysis": {
    "keyResponsibilities": ["responsibility 1", "responsibility 2"],
    "requiredSkills": ["skill 1", "skill 2"],
    "successMetrics": ["metric 1", "metric 2"]
  }
}

Include:
1. Common interview questions for this role
2. Company-specific research guidance
3. Role-specific preparation
4. Technical and behavioral questions
5. Sample answers and tips`;

    const response = await aiService.generateJSON<InterviewPreparation>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.6,
    });

    return response || {
      questions: [],
      companyResearch: { overview: '', culture: '', recentNews: [] },
      roleAnalysis: { keyResponsibilities: [], requiredSkills: [], successMetrics: [] },
    };
  }

  async getSalaryNegotiationAdvice(params: {
    jobTitle: string;
    experience: number;
    location: string;
    industry: string;
    currentSalary?: number;
    offerAmount?: number;
    skills: string[];
  }): Promise<SalaryNegotiationAdvice> {
    const prompt = `Provide salary negotiation advice for the following situation:

Job Title: ${params.jobTitle}
Years of Experience: ${params.experience}
Location: ${params.location}
Industry: ${params.industry}
${params.currentSalary ? `Current Salary: ${params.currentSalary}` : ''}
${params.offerAmount ? `Offer Amount: ${params.offerAmount}` : ''}
Key Skills: ${params.skills.join(', ')}

Please provide comprehensive salary negotiation advice in JSON format:
{
  "marketRate": {
    "min": number,
    "average": number,
    "max": number,
    "currency": "USD"
  },
  "negotiationStrategy": ["strategy 1", "strategy 2"],
  "talkingPoints": ["point 1", "point 2"],
  "counterOfferSuggestions": ["suggestion 1", "suggestion 2"],
  "benefitsToConsider": ["benefit 1", "benefit 2"]
}

Include:
1. Market rate analysis for the role/location
2. Negotiation strategies and tactics
3. Key talking points
4. Counter-offer suggestions
5. Non-salary benefits to consider`;

    const response = await aiService.generateJSON<SalaryNegotiationAdvice>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.5,
    });

    return response || {
      marketRate: { min: 0, average: 0, max: 0, currency: 'USD' },
      negotiationStrategy: [],
      talkingPoints: [],
      counterOfferSuggestions: [],
      benefitsToConsider: [],
    };
  }

  async generateJobRecommendations(params: {
    profile: {
      skills: string[];
      experience: number;
      preferredRoles: string[];
      location: string;
      industry: string;
      workType: 'full-time' | 'part-time' | 'contract' | 'remote';
    };
    careerGoals: string[];
    searchHistory?: string[];
  }): Promise<Array<{
    title: string;
    company: string;
    location: string;
    matchScore: number;
    reasons: string[];
    description: string;
  }>> {
    const prompt = `Generate personalized job recommendations based on the following profile:

Candidate Profile:
- Skills: ${params.profile.skills.join(', ')}
- Experience: ${params.profile.experience} years
- Preferred Roles: ${params.profile.preferredRoles.join(', ')}
- Location: ${params.profile.location}
- Industry: ${params.profile.industry}
- Work Type: ${params.profile.workType}

Career Goals: ${params.careerGoals.join(', ')}
${params.searchHistory ? `Recent Search History: ${params.searchHistory.join(', ')}` : ''}

Please provide job recommendations in JSON format:
[
  {
    "title": "job title",
    "company": "company name",
    "location": "location",
    "matchScore": number (0-100),
    "reasons": ["reason 1", "reason 2"],
    "description": "job description"
  }
]

Generate 5-8 relevant job recommendations that:
1. Match the candidate's skills and experience
2. Align with career goals
3. Consider location and work type preferences
4. Include realistic companies and roles
5. Provide clear reasoning for each recommendation`;

    const response = await aiService.generateJSON<Array<{
      title: string;
      company: string;
      location: string;
      matchScore: number;
      reasons: string[];
      description: string;
    }>>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.7,
    });

    return response || [];
  }

  async provideResumeFeedback(params: {
    resumeText: string;
    targetRole?: string;
    industry: string;
  }): Promise<{
    overallScore: number;
    strengths: string[];
    improvements: string[];
    sectionScores: {
      summary: number;
      experience: number;
      skills: number;
      education: number;
    };
    atsOptimization: string[];
  }> {
    const prompt = `Provide detailed feedback on the following resume:

Resume Text:
${params.resumeText}
${params.targetRole ? `Target Role: ${params.targetRole}` : ''}
Industry: ${params.industry}

Please provide comprehensive resume feedback in JSON format:
{
  "overallScore": number (0-100),
  "strengths": ["strength 1", "strength 2"],
  "improvements": ["improvement 1", "improvement 2"],
  "sectionScores": {
    "summary": number (0-100),
    "experience": number (0-100),
    "skills": number (0-100),
    "education": number (0-100)
  },
  "atsOptimization": ["optimization tip 1", "optimization tip 2"]
}

Focus on:
1. Overall effectiveness and impact
2. Content quality and relevance
3. ATS optimization
4. Section-specific feedback
5. Actionable improvement suggestions`;

    const response = await aiService.generateJSON<{
      overallScore: number;
      strengths: string[];
      improvements: string[];
      sectionScores: {
        summary: number;
        experience: number;
        skills: number;
        education: number;
      };
      atsOptimization: string[];
    }>(prompt, {
      systemPrompt: this.systemPrompt,
      temperature: 0.4,
    });

    return response || {
      overallScore: 0,
      strengths: [],
      improvements: [],
      sectionScores: { summary: 0, experience: 0, skills: 0, education: 0 },
      atsOptimization: [],
    };
  }
}

export const aiAgentSystem = new AIAgentSystem();