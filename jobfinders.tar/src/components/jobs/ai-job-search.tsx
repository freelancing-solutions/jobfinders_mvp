'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Search, 
  Brain, 
  Target, 
  Sparkles, 
  MapPin, 
  Briefcase, 
  Filter,
  RefreshCw,
  TrendingUp,
  Users,
  Star,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

interface JobRecommendation {
  title: string;
  company: string;
  location: string;
  description: string;
  salary: { min: number; max: number; currency: string };
  type: string;
  remoteAllowed: boolean;
  matchScore: number;
  reasons: string[];
  skills: string[];
  industry: string;
}

interface UserProfile {
  skills: string[];
  experience: number;
  experienceLevel: 'entry' | 'mid' | 'senior' | 'executive';
  location: string;
  preferredLocations: string[];
  industry: string;
  jobTitles: string[];
  salaryExpectation: { min: number; max: number; currency: string };
  workType: 'full-time' | 'part-time' | 'contract' | 'internship';
  remotePreference: boolean;
}

export function AIJobSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');
  const [userProfile, setUserProfile] = useState<UserProfile>({
    skills: [],
    experience: 0,
    experienceLevel: 'mid',
    location: '',
    preferredLocations: [],
    industry: '',
    jobTitles: [],
    salaryExpectation: { min: 0, max: 0, currency: 'USD' },
    workType: 'full-time',
    remotePreference: false,
  });
  const [recommendations, setRecommendations] = useState<JobRecommendation[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('search');
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);

  const handleGenerateRecommendations = async () => {
    if (!userProfile.skills.length && !searchQuery) {
      alert('Please provide your skills or a search query');
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'job-recommendations',
          params: {
            profile: userProfile,
            careerGoals: searchQuery ? [searchQuery] : [],
            searchHistory: [],
          },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setRecommendations(result);
      }
    } catch (error) {
      console.error('Failed to generate recommendations:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleOptimizeSearch = async () => {
    if (!searchQuery.trim()) return;

    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'generate-text',
          params: {
            prompt: `Optimize this job search query for better results: "${searchQuery}". Provide 3-5 improved search queries that would yield better job matches.`,
            systemPrompt: 'You are an expert job search optimizer. Help users improve their search queries to find better job matches.',
            temperature: 0.7,
          },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        const suggestions = result.content.split('\n').filter(s => s.trim());
        setAiSuggestions(suggestions);
      }
    } catch (error) {
      console.error('Failed to optimize search:', error);
    }
  };

  const handleExtractSkills = async (text: string) => {
    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'extract-skills',
          params: { text },
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setUserProfile(prev => ({
          ...prev,
          skills: [...prev.skills, ...result.technical, ...result.soft],
        }));
      }
    } catch (error) {
      console.error('Failed to extract skills:', error);
    }
  };

  const getMatchColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-blue-600 bg-blue-100';
    if (score >= 40) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Brain className="h-8 w-8" />
          AI-Powered Job Search
        </h1>
        <p className="text-muted-foreground">
          Discover your perfect job match with intelligent AI recommendations
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="search" className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Smart Search
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Profile Setup
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Recommendations
          </TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                AI Job Search
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Describe your ideal job or paste your resume..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Preferred location..."
                    className="pl-9"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleGenerateRecommendations}
                  disabled={isGenerating || (!searchQuery.trim() && userProfile.skills.length === 0)}
                  className="flex items-center gap-2"
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Finding Matches...
                    </>
                  ) : (
                    <>
                      <Brain className="h-4 w-4" />
                      Find AI Matches
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={handleOptimizeSearch}
                  disabled={!searchQuery.trim()}
                  className="flex items-center gap-2"
                >
                  <Sparkles className="h-4 w-4" />
                  Optimize Search
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleExtractSkills(searchQuery)}
                  disabled={!searchQuery.trim()}
                  className="flex items-center gap-2"
                >
                  <Target className="h-4 w-4" />
                  Extract Skills
                </Button>
              </div>

              {aiSuggestions.length > 0 && (
                <Alert>
                  <Sparkles className="h-4 w-4" />
                  <AlertDescription>
                    <strong>AI Search Suggestions:</strong>
                    <div className="mt-2 space-y-1">
                      {aiSuggestions.map((suggestion, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <button
                            onClick={() => setSearchQuery(suggestion)}
                            className="text-blue-600 hover:text-blue-800 underline text-sm"
                          >
                            {suggestion}
                          </button>
                        </div>
                      ))}
                    </div>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <div className="grid md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">{recommendations.length}</p>
                <p className="text-sm text-muted-foreground">AI Matches</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Star className="h-8 w-8 text-green-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">
                  {recommendations.filter(r => r.matchScore >= 80).length}
                </p>
                <p className="text-sm text-muted-foreground">Strong Matches</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Briefcase className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">{userProfile.skills.length}</p>
                <p className="text-sm text-muted-foreground">Skills Profiled</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Users className="h-8 w-8 text-orange-500 mx-auto mb-2" />
                <p className="text-2xl font-bold">
                  {recommendations.length > 0 ? Math.round(recommendations.reduce((sum, r) => sum + r.matchScore, 0) / recommendations.length) : 0}%
                </p>
                <p className="text-sm text-muted-foreground">Avg Match Score</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Your Professional Profile
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Skills (comma-separated)</label>
                  <Textarea
                    placeholder="JavaScript, React, Python, Project Management..."
                    value={userProfile.skills.join(', ')}
                    onChange={(e) => setUserProfile(prev => ({
                      ...prev,
                      skills: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                    }))}
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Experience</label>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-muted-foreground">Years</label>
                      <Input
                        type="number"
                        value={userProfile.experience}
                        onChange={(e) => setUserProfile(prev => ({
                          ...prev,
                          experience: parseInt(e.target.value) || 0
                        }))}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Level</label>
                      <select
                        value={userProfile.experienceLevel}
                        onChange={(e) => setUserProfile(prev => ({
                          ...prev,
                          experienceLevel: e.target.value as any
                        }))}
                        className="w-full p-2 border rounded-md"
                      >
                        <option value="entry">Entry Level</option>
                        <option value="mid">Mid Level</option>
                        <option value="senior">Senior Level</option>
                        <option value="executive">Executive</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Location</label>
                  <Input
                    placeholder="Current location"
                    value={userProfile.location}
                    onChange={(e) => setUserProfile(prev => ({
                      ...prev,
                      location: e.target.value
                    }))}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Industry</label>
                  <Input
                    placeholder="Technology, Healthcare, Finance..."
                    value={userProfile.industry}
                    onChange={(e) => setUserProfile(prev => ({
                      ...prev,
                      industry: e.target.value
                    }))}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Salary Expectation ({userProfile.salaryExpectation.currency})</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      placeholder="Min"
                      value={userProfile.salaryExpectation.min}
                      onChange={(e) => setUserProfile(prev => ({
                        ...prev,
                        salaryExpectation: { ...prev.salaryExpectation, min: parseInt(e.target.value) || 0 }
                      }))}
                    />
                    <Input
                      type="number"
                      placeholder="Max"
                      value={userProfile.salaryExpectation.max}
                      onChange={(e) => setUserProfile(prev => ({
                        ...prev,
                        salaryExpectation: { ...prev.salaryExpectation, max: parseInt(e.target.value) || 0 }
                      }))}
                    />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Work Type</label>
                  <select
                    value={userProfile.workType}
                    onChange={(e) => setUserProfile(prev => ({
                      ...prev,
                      workType: e.target.value as any
                    }))}
                    className="w-full p-2 border rounded-md"
                  >
                    <option value="full-time">Full Time</option>
                    <option value="part-time">Part Time</option>
                    <option value="contract">Contract</option>
                    <option value="internship">Internship</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="remote"
                  checked={userProfile.remotePreference}
                  onChange={(e) => setUserProfile(prev => ({
                    ...prev,
                    remotePreference: e.target.checked
                  }))}
                />
                <label htmlFor="remote" className="text-sm">Open to remote work</label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          {recommendations.length > 0 ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">AI Job Recommendations</h2>
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Refresh
                </Button>
              </div>

              {recommendations
                .sort((a, b) => b.matchScore - a.matchScore)
                .map((job, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-medium">{job.title}</h3>
                            <Badge className={getMatchColor(job.matchScore)}>
                              {job.matchScore}% Match
                            </Badge>
                            {job.remoteAllowed && (
                              <Badge variant="outline">Remote</Badge>
                            )}
                          </div>
                          
                          <div className="grid md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <p className="text-sm text-muted-foreground">
                                <Briefcase className="inline h-4 w-4 mr-1" />
                                {job.company}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                <MapPin className="inline h-4 w-4 mr-1" />
                                {job.location}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                💰 {job.salary.currency} {job.salary.min.toLocaleString()} - {job.salary.max.toLocaleString()}
                              </p>
                            </div>
                            
                            <div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {job.type} • {job.industry}
                              </p>
                              <div className="flex flex-wrap gap-1">
                                {job.skills.slice(0, 6).map((skill, skillIndex) => (
                                  <Badge key={skillIndex} variant="outline" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                                {job.skills.length > 6 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{job.skills.length - 6} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>

                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                            {job.description}
                          </p>
                        </div>
                        
                        <div className="flex gap-2 ml-4">
                          <Button size="sm">View Details</Button>
                          <Button variant="outline" size="sm">Apply</Button>
                        </div>
                      </div>
                      
                      {/* Match Reasons */}
                      <div className="border-t pt-4">
                        <h4 className="font-medium text-sm mb-2 text-green-600">Why this matches:</h4>
                        <ul className="space-y-1">
                          {job.reasons.slice(0, 3).map((reason, reasonIndex) => (
                            <li key={reasonIndex} className="text-xs flex items-start gap-1">
                              <CheckCircle className="h-3 w-3 text-green-500 mt-0.5 flex-shrink-0" />
                              {reason}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Recommendations Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Set up your profile and search for jobs to get AI-powered recommendations.
                </p>
                <Button onClick={() => setActiveTab('search')}>
                  Get Started
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}