import ZAI from 'z-ai-web-dev-sdk';
import { openRouterConfig } from '@/config/openrouter';

export interface AIServiceConfig {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
}

export interface AIResponse {
  content: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  error?: string;
}

export class AIService {
  private zai: any;
  private isInitialized: boolean = false;

  constructor() {
    this.zai = null;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      this.zai = await ZAI.create();
      this.isInitialized = true;
      console.log('AI Service initialized successfully');
    } catch (error) {
      console.error('Failed to initialize AI Service:', error);
      throw new Error('AI Service initialization failed');
    }
  }

  async generateText(
    prompt: string,
    config: AIServiceConfig = {}
  ): Promise<AIResponse> {
    if (!this.isInitialized) {
      await this.initialize();
    }

    try {
      const messages = [];

      if (config.systemPrompt) {
        messages.push({
          role: 'system',
          content: config.systemPrompt,
        });
      }

      messages.push({
        role: 'user',
        content: prompt,
      });

      const completion = await this.zai.chat.completions.create({
        messages,
        temperature: config.temperature ?? 0.7,
        max_tokens: config.maxTokens ?? 1000,
        model: config.model ?? 'gpt-3.5-turbo',
      });

      return {
        content: completion.choices[0]?.message?.content || '',
        usage: {
          promptTokens: completion.usage?.prompt_tokens || 0,
          completionTokens: completion.usage?.completion_tokens || 0,
          totalTokens: completion.usage?.total_tokens || 0,
        },
      };
    } catch (error) {
      console.error('AI text generation failed:', error);
      return {
        content: '',
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  async generateJSON<T>(
    prompt: string,
    config: AIServiceConfig = {}
  ): Promise<T | null> {
    const jsonPrompt = `${prompt}

Please respond with a valid JSON object only. Do not include any explanations or additional text.`;

    const response = await this.generateText(jsonPrompt, config);

    if (response.error) {
      console.error('JSON generation failed:', response.error);
      return null;
    }

    try {
      return JSON.parse(response.content) as T;
    } catch (error) {
      console.error('Failed to parse AI response as JSON:', error);
      return null;
    }
  }

  async analyzeText(
    text: string,
    analysisType: 'sentiment' | 'keywords' | 'summary' | 'skills'
  ): Promise<AIResponse> {
    const systemPrompts = {
      sentiment: 'You are an expert at analyzing sentiment. Provide a detailed sentiment analysis.',
      keywords: 'You are an expert at extracting keywords and key phrases. Extract the most important keywords.',
      summary: 'You are an expert at summarizing text. Provide a concise summary.',
      skills: 'You are an expert at identifying skills from text. Extract technical and soft skills.',
    };

    const prompts = {
      sentiment: `Analyze the sentiment of the following text and provide a detailed analysis including overall sentiment (positive, negative, neutral), confidence level, and key emotional indicators:\n\n${text}`,
      keywords: `Extract the most important keywords and key phrases from the following text. Focus on technical terms, skills, and concepts. Return as a comma-separated list:\n\n${text}`,
      summary: `Provide a concise summary of the following text, capturing the main points and key information:\n\n${text}`,
      skills: `Extract all technical skills, soft skills, and qualifications from the following text. Categorize them as technical or soft skills:\n\n${text}`,
    };

    return this.generateText(prompts[analysisType], {
      systemPrompt: systemPrompts[analysisType],
      temperature: 0.3,
    });
  }

  async isAvailable(): Promise<boolean> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }
      
      // Test with a simple prompt
      const testResponse = await this.generateText('Test', {
        maxTokens: 1,
      });
      
      return !testResponse.error;
    } catch (error) {
      console.error('AI service availability check failed:', error);
      return false;
    }
  }
}

// Singleton instance
export const aiService = new AIService();