import { aiService } from './ai-service';
import { redis } from '@/lib/redis';

export interface CandidateProfile {
  id: string;
  skills: string[];
  experience: number;
  experienceLevel: 'entry' | 'mid' | 'senior' | 'executive';
  location: string;
  salaryExpectation: { min: number; max: number; currency: string };
  industry: string;
  jobTitles: string[];
  education: { degree: string; field: string };
  preferences: {
    remoteWork: boolean;
    relocation: boolean;
    workType: 'full-time' | 'part-time' | 'contract' | 'internship';
  };
}

export interface JobProfile {
  id: string;
  title: string;
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experience: { min: number; level: 'entry' | 'mid' | 'senior' | 'executive' };
  location: string;
  salary: { min: number; max: number; currency: string };
  industry: string;
  type: 'full-time' | 'part-time' | 'contract' | 'internship';
  remoteAllowed: boolean;
  company: { name: string; size: string; industry: string };
}

export interface MatchResult {
  candidateId: string;
  jobId: string;
  overallScore: number;
  breakdown: {
    skillsMatch: number;
    experienceMatch: number;
    locationMatch: number;
    salaryMatch: number;
    cultureFit: number;
    educationMatch: number;
  };
  strengths: string[];
  concerns: string[];
  recommendation: 'strong' | 'good' | 'moderate' | 'weak';
  explanation: string;
}

export interface MatchingConfig {
  weights: {
    skills: number;
    experience: number;
    location: number;
    salary: number;
    culture: number;
    education: number;
  };
  thresholds: {
    minimumScore: number;
    strongMatch: number;
    goodMatch: number;
  };
}

export class MatchingEngine {
  private defaultConfig: MatchingConfig = {
    weights: {
      skills: 0.35,
      experience: 0.25,
      location: 0.15,
      salary: 0.10,
      culture: 0.10,
      education: 0.05,
    },
    thresholds: {
      minimumScore: 40,
      strongMatch: 80,
      goodMatch: 65,
    },
  };

  async matchCandidateToJob(
    candidate: CandidateProfile,
    job: JobProfile,
    config: MatchingConfig = this.defaultConfig
  ): Promise<MatchResult> {
    // Try to get from cache first
    const cacheKey = `match:${candidate.id}:${job.id}`;
    
    if (redis) {
      try {
        const cached = await redis.get(cacheKey);
        if (cached) {
          return JSON.parse(cached);
        }
      } catch (error) {
        console.log('Cache miss, proceeding with matching');
      }
    }

    // Calculate individual match scores
    const skillsScore = this.calculateSkillsMatch(candidate.skills, job.requiredSkills, job.preferredSkills);
    const experienceScore = this.calculateExperienceMatch(candidate.experience, candidate.experienceLevel, job.experience);
    const locationScore = this.calculateLocationMatch(candidate.location, job.location, candidate.preferences.remoteWork, job.remoteAllowed);
    const salaryScore = this.calculateSalaryMatch(candidate.salaryExpectation, job.salary);
    const cultureScore = await this.calculateCultureFit(candidate, job);
    const educationScore = this.calculateEducationMatch(candidate.education, job);

    // Calculate weighted overall score
    const overallScore = Math.round(
      skillsScore * config.weights.skills +
      experienceScore * config.weights.experience +
      locationScore * config.weights.location +
      salaryScore * config.weights.salary +
      cultureScore * config.weights.culture +
      educationScore * config.weights.education
    );

    // Generate AI-powered explanation and recommendations
    const aiAnalysis = await this.generateMatchAnalysis(candidate, job, {
      skillsScore,
      experienceScore,
      locationScore,
      salaryScore,
      cultureScore,
      educationScore,
      overallScore,
    });

    const result: MatchResult = {
      candidateId: candidate.id,
      jobId: job.id,
      overallScore,
      breakdown: {
        skillsMatch: skillsScore,
        experienceMatch: experienceScore,
        locationMatch: locationScore,
        salaryMatch: salaryScore,
        cultureFit: cultureScore,
        educationMatch: educationScore,
      },
      strengths: aiAnalysis.strengths,
      concerns: aiAnalysis.concerns,
      recommendation: this.getRecommendation(overallScore, config.thresholds),
      explanation: aiAnalysis.explanation,
    };

    // Cache the result
    if (redis) {
      try {
        await redis.setex(cacheKey, 3600, JSON.stringify(result)); // Cache for 1 hour
      } catch (error) {
        console.error('Failed to cache match result:', error);
      }
    }

    return result;
  }

  private calculateSkillsMatch(
    candidateSkills: string[],
    requiredSkills: string[],
    preferredSkills: string[]
  ): number {
    const allJobSkills = [...requiredSkills, ...preferredSkills];
    const normalizedCandidateSkills = candidateSkills.map(skill => skill.toLowerCase());
    const normalizedJobSkills = allJobSkills.map(skill => skill.toLowerCase());

    // Calculate exact matches
    const exactMatches = normalizedCandidateSkills.filter(skill =>
      normalizedJobSkills.includes(skill)
    ).length;

    // Calculate partial matches (using simple substring matching)
    const partialMatches = normalizedCandidateSkills.filter(skill =>
      normalizedJobSkills.some(jobSkill => 
        skill.includes(jobSkill) || jobSkill.includes(skill)
      )
    ).length - exactMatches;

    const totalPossible = normalizedJobSkills.length;
    if (totalPossible === 0) return 50; // Neutral score if no skills specified

    // Weight exact matches more heavily
    const weightedScore = (exactMatches * 2 + partialMatches * 1) / (totalPossible * 2);
    return Math.min(100, Math.round(weightedScore * 100));
  }

  private calculateExperienceMatch(
    candidateYears: number,
    candidateLevel: string,
    jobExperience: { min: number; level: string }
  ): number {
    // Check if candidate meets minimum years requirement
    const yearsScore = candidateYears >= jobExperience.min ? 100 : Math.max(0, (candidateYears / jobExperience.min) * 100);

    // Check level match
    const levels = ['entry', 'mid', 'senior', 'executive'];
    const candidateLevelIndex = levels.indexOf(candidateLevel);
    const jobLevelIndex = levels.indexOf(jobExperience.level);

    let levelScore = 100;
    if (candidateLevelIndex < jobLevelIndex - 1) {
      levelScore = 50; // Underqualified
    } else if (candidateLevelIndex > jobLevelIndex + 1) {
      levelScore = 70; // Overqualified but acceptable
    }

    return Math.round((yearsScore + levelScore) / 2);
  }

  private calculateLocationMatch(
    candidateLocation: string,
    jobLocation: string,
    candidateRemote: boolean,
    jobRemoteAllowed: boolean
  ): number {
    // If job allows remote work and candidate is open to remote
    if (jobRemoteAllowed && candidateRemote) {
      return 100;
    }

    // If both require on-site and locations match
    if (!jobRemoteAllowed && !candidateRemote) {
      // Simple location matching - in real implementation, use geocoding
      const candidateCity = candidateLocation.split(',')[0].trim().toLowerCase();
      const jobCity = jobLocation.split(',')[0].trim().toLowerCase();
      
      if (candidateCity === jobCity) {
        return 100;
      }
      
      // Check if same country/region
      const candidateRegion = candidateLocation.split(',').slice(1).join(',').trim().toLowerCase();
      const jobRegion = jobLocation.split(',').slice(1).join(',').trim().toLowerCase();
      
      if (candidateRegion === jobRegion) {
        return 80;
      }
    }

    return 30; // Poor location match
  }

  private calculateSalaryMatch(
    candidateExpectation: { min: number; max: number; currency: string },
    jobSalary: { min: number; max: number; currency: string }
  ): number {
    if (candidateExpectation.currency !== jobSalary.currency) {
      return 50; // Currency mismatch - neutral score
    }

    // Check if salary ranges overlap
    const overlapMin = Math.max(candidateExpectation.min, jobSalary.min);
    const overlapMax = Math.min(candidateExpectation.max, jobSalary.max);
    
    if (overlapMax >= overlapMin) {
      // There's an overlap
      const overlapRange = overlapMax - overlapMin;
      const candidateRange = candidateExpectation.max - candidateExpectation.min;
      const jobRange = jobSalary.max - jobSalary.min;
      
      const overlapPercentage = overlapRange / Math.max(candidateRange, jobRange);
      return Math.min(100, Math.round(overlapPercentage * 100));
    }

    // No overlap, check how close they are
    const gap = Math.min(
      Math.abs(candidateExpectation.max - jobSalary.min),
      Math.abs(jobSalary.max - candidateExpectation.min)
    );
    
    const maxGap = Math.max(
      candidateExpectation.max - candidateExpectation.min,
      jobSalary.max - jobSalary.min
    );
    
    const gapScore = Math.max(0, 100 - (gap / maxGap) * 100);
    return Math.round(gapScore);
  }

  private async calculateCultureFit(candidate: CandidateProfile, job: JobProfile): Promise<number> {
    // Use AI to assess cultural fit based on available information
    const prompt = `Assess the cultural fit between a candidate and a company based on the following information:

Candidate Profile:
- Industry: ${candidate.industry}
- Experience Level: ${candidate.experienceLevel}
- Preferred Work Type: ${candidate.preferences.workType}
- Remote Work Preference: ${candidate.preferences.remoteWork}
- Relocation Willingness: ${candidate.preferences.relocation}

Job/Company Profile:
- Company: ${job.company.name}
- Industry: ${job.industry}
- Company Size: ${job.company.size}
- Job Type: ${job.type}
- Remote Allowed: ${job.remoteAllowed}

Please provide a cultural fit score from 0-100 based on:
1. Industry alignment
2. Work style compatibility (remote vs in-office)
3. Company size vs experience level fit
4. Work type alignment

Return only the score as a number.`;

    const response = await aiService.generateText(prompt, {
      temperature: 0.2,
    });

    const score = parseInt(response.content);
    return isNaN(score) ? 75 : Math.max(0, Math.min(100, score)); // Default to 75 if parsing fails
  }

  private calculateEducationMatch(
    candidateEducation: { degree: string; field: string },
    jobEducation?: { degree: string; field?: string }
  ): number {
    if (!jobEducation) return 100; // No specific education requirements

    // Simple degree level matching
    const degreeLevels = ['high school', 'associate', 'bachelor', 'master', 'phd'];
    const candidateLevel = degreeLevels.findIndex(level => 
      candidateEducation.degree.toLowerCase().includes(level)
    );
    const jobLevel = degreeLevels.findIndex(level => 
      jobEducation.degree.toLowerCase().includes(level)
    );

    if (candidateLevel >= jobLevel) {
      return 100; // Meets or exceeds education requirement
    }

    // Partial credit if close
    if (candidateLevel === jobLevel - 1) {
      return 70;
    }

    return 40; // Significant education gap
  }

  private getRecommendation(score: number, thresholds: { minimumScore: number; strongMatch: number; goodMatch: number }): 'strong' | 'good' | 'moderate' | 'weak' {
    if (score >= thresholds.strongMatch) return 'strong';
    if (score >= thresholds.goodMatch) return 'good';
    if (score >= thresholds.minimumScore) return 'moderate';
    return 'weak';
  }

  private async generateMatchAnalysis(
    candidate: CandidateProfile,
    job: JobProfile,
    scores: { [key: string]: number }
  ): Promise<{ strengths: string[]; concerns: string[]; explanation: string }> {
    const prompt = `Generate a detailed analysis of a candidate-job match based on the following information:

Candidate Profile:
${JSON.stringify(candidate, null, 2)}

Job Profile:
${JSON.stringify(job, null, 2)}

Match Scores:
${JSON.stringify(scores, null, 2)}

Please provide a JSON response with:
{
  "strengths": ["strength1", "strength2"],
  "concerns": ["concern1", "concern2"],
  "explanation": "detailed explanation of the match"
}`;

    return await aiService.generateJSON<{ strengths: string[]; concerns: string[]; explanation: string }>(prompt, {
      systemPrompt: 'You are an expert recruiter analyzing candidate-job matches.',
      temperature: 0.3,
    }) || { strengths: [], concerns: [], explanation: '' };
  }

  async findTopMatches(
    candidate: CandidateProfile,
    jobs: JobProfile[],
    limit: number = 10
  ): Promise<MatchResult[]> {
    const matches: MatchResult[] = [];

    for (const job of jobs) {
      const match = await this.matchCandidateToJob(candidate, job);
      if (match.overallScore >= this.defaultConfig.thresholds.minimumScore) {
        matches.push(match);
      }
    }

    // Sort by score and return top matches
    return matches
      .sort((a, b) => b.overallScore - a.overallScore)
      .slice(0, limit);
  }
}

export const matchingEngine = new MatchingEngine();