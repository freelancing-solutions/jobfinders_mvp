import { MatchingDashboard } from '@/components/matching/matching-dashboard';

export default function MatchingDashboardPage() {
  return <MatchingDashboard />;
}