import { ATSAnalyzer } from '@/components/ats/ats-analyzer';

export default function ATSAnalyzerPage() {
  return <ATSAnalyzer />;
}